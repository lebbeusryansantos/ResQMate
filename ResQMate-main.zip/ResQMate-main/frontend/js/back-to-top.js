/* Back-to-Top button logic — shared by all dashboard pages.
   Shows the button after 300px of scrolling, hides it again near the top,
   and smoothly scrolls to the top on click. Does nothing if the button is absent. */
(function () {
    "use strict";

    var SHOW_AFTER = 300;   // px scrolled before the button appears

    function init() {
        var btn = document.getElementById("backToTopBtn");
        if (!btn) return;

        var visible = false;
        var ticking = false;
        var hideTimer = null;

        function scrollY() {
            return window.pageYOffset || document.documentElement.scrollTop || 0;
        }

        function show() {
            if (visible) return;
            visible = true;
            clearTimeout(hideTimer);
            btn.classList.add("is-rendered");          // display: flex
            // next frame so the opacity transition actually plays
            requestAnimationFrame(function () {
                requestAnimationFrame(function () {
                    if (visible) btn.classList.add("show");
                });
            });
        }

        function hide() {
            if (!visible) return;
            visible = false;
            btn.classList.remove("show");              // fade out
            clearTimeout(hideTimer);
            hideTimer = setTimeout(function () {
                if (!visible) btn.classList.remove("is-rendered");   // display: none
            }, 320);
        }

        function update() {
            ticking = false;
            if (scrollY() > SHOW_AFTER) show(); else hide();
        }

        window.addEventListener("scroll", function () {
            if (!ticking) {
                ticking = true;
                requestAnimationFrame(update);
            }
        }, { passive: true });

        btn.addEventListener("click", function () {
            var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
            window.scrollTo({ top: 0, behavior: reduce ? "auto" : "smooth" });
        });

        update();   // correct state if the browser restored a scrolled position
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
